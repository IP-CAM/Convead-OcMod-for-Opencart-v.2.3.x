<?php
$_['heading_title']    = 'Convead';
$_['text_module']      = 'Modules';
$_['text_edit']        = 'Module settings';
$_['entry_status']     = 'Status';
$_['entry_apikey']     = 'API Key';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['button_save']      = 'Save';
$_['button_cancel']    = 'Cancel';
$_['curl_disable']     = 'Attention! On the hosting is not enabled CURL support. It is necessary for the operation of the module.';