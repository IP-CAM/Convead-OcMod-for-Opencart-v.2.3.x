<?php
$_['heading_title']    = 'Convead';
$_['text_module']      = 'Модули';
$_['text_edit']        = 'Настройки модуля';
$_['entry_status']     = 'Статус';
$_['entry_apikey']     = 'API Key';
$_['text_enabled']     = 'Включено';
$_['text_disabled']    = 'Отключено';
$_['button_save']      = 'Сохранить';
$_['button_cancel']    = 'Отменить';
$_['curl_disable']     = 'Внимание! На хостинге не включена поддержка CURL. Она необходима для работы модуля.';